# Circle to Search

Personal Android 15 Digital Assistant bridge for the Redmi Note 12S.

## Intended behavior

Digital Assistant invocation -> Circle to Search -> selected target app.

The app does not request INTERNET permission and contains no voice-recognition implementation.

## Build

Open this folder in Android Studio with a JDK 17 installation.

Then use:

Build -> Build APK(s)

After installation, open Circle to Search, select the target app, and choose Circle to Search as the system Digital Assistant.

## Important

The icon in this first project package is a temporary vector placeholder. Replace
`app/src/main/res/drawable/ic_circle_to_search.xml` with the previously designed
Circle to Search icon before the final build.
